import 'server-only';import {createClient} from '@supabase/supabase-js';import {jwtVerify,SignJWT} from 'jose';import {cookies} from 'next/headers';
export function db(){if(!process.env.SUPABASE_URL||!process.env.SUPABASE_SERVICE_ROLE_KEY)throw Error('Database is not configured');return createClient(process.env.SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY,{auth:{persistSession:false}})}
function secret(){if(!process.env.ADMIN_SESSION_SECRET||process.env.ADMIN_SESSION_SECRET.length<32)throw Error('ADMIN_SESSION_SECRET missing');return new TextEncoder().encode(process.env.ADMIN_SESSION_SECRET)}
export async function admin(){try{const token=(await cookies()).get('muvik_admin')?.value;if(!token)return false;await jwtVerify(token,secret());return true}catch{return false}}
export async function token(){return new SignJWT({role:'admin'}).setProtectedHeader({alg:'HS256'}).setIssuedAt().setExpirationTime('12h').sign(secret())}
