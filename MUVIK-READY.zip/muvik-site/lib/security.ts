import {NextRequest,NextResponse} from 'next/server';

/** Reject browser cross-origin mutations; never trust a caller-supplied Origin. */
export function rejectCrossOrigin(req:NextRequest){
  const origin=req.headers.get('origin');
  const expected=process.env.APP_ORIGIN || req.nextUrl.origin;
  if(origin && origin!==expected){
    return NextResponse.json({error:'Недопустимый источник запроса.'},{status:403});
  }
  const type=req.headers.get('content-type')||'';
  if(!type.toLowerCase().startsWith('application/json')){
    return NextResponse.json({error:'Ожидается JSON.'},{status:415});
  }
  const length=Number(req.headers.get('content-length')||0);
  if(length>16000)return NextResponse.json({error:'Слишком большая анкета.'},{status:413});
  return null;
}
