# MUVIK — DEAD INSIDE RECRUITMENT

Next.js 15 + TypeScript + Tailwind + Framer Motion + Supabase + server-side Discord webhook.

## Launch

1. `npm install`
2. Create a Supabase project, run `supabase/schema.sql` in SQL Editor.
3. Copy `.env.example` to `.env.local` and fill in secrets. **Never use `NEXT_PUBLIC_` for secrets.**
4. Generate a bcrypt password hash: `node -e "require('bcryptjs').hash('YOUR_PASSWORD',12).then(console.log)"` after installing dependencies. Set `ADMIN_PASSWORD_HASH`.
5. Generate two random secrets, each at least 32 chars (e.g. `openssl rand -hex 32`).
6. Create a Discord channel webhook and set `DISCORD_WEBHOOK_URL`.
7. `npm run dev`; deploy to Vercel with the same environment variables.

Applications are stored in Supabase with RLS enabled and **no public policies**. Only server-side service-role code can read them. Admin login uses a server-verified signed HttpOnly cookie. The public form rate-limits to 3 applications per IP hash per hour, uses a honeypot, and validates inputs with Zod. For high-traffic production use, add edge-level bot protection and distributed rate limiting; the current database limit is best-effort under concurrent requests. Admin login should also be protected by edge rate limiting before public launch.

**Notification semantics:** the application is saved first; only then is the Discord webhook called. If Discord fails, the UI explicitly reports that the application was saved but notification failed. No fake success states. Configure an alert/retry worker if guaranteed webhook delivery is required.

**Assets:** This project deliberately uses original abstract red/black hero art built in CSS rather than shipping unlicensed Shadow Fiend imagery. Replace with appropriately licensed artwork if available. The music toggle switches a visual atmosphere state; no audio is bundled or claimed to play. To add playback, supply an authorized audio file and implement an HTML audio control.

**Privacy:** configure a retention period for applicant data and publish your privacy notice before accepting real applications.

## Deployment readiness

- API mutation routes check browser Origin, enforce JSON payloads and reject oversized public submissions.
- Discord failure is **not** reported as a successful notification. The applicant sees a saved-but-not-notified warning and should not submit again.
- Configure `APP_ORIGIN` with the final HTTPS origin in production (no trailing slash).
- Before launch, implement a **distributed** admin-login rate limit (e.g. Vercel WAF / Upstash) and CAPTCHA/Turnstile for public forms. Database-backed application limits are not atomic under concurrency.
- The repository cannot be considered production-verified until `npm install`, `npm run build`, database migrations and an end-to-end form test pass in the deployment environment.
