create extension if not exists pgcrypto;
create table if not exists public.applications (id uuid primary key default gen_random_uuid(),created_at timestamptz not null default now(),nickname text not null,discord text not null,steam text,age integer,mmr integer not null,role text not null,heroes text[] not null default '{}',dead_inside integer not null,zxc text,lil_peep text,support text,elevate text,floor text,why text,status text not null default 'Новая' check(status in ('Новая','На рассмотрении','Принят','Отклонён')),ip_hash text not null);
create index if not exists applications_created_idx on public.applications(created_at desc);
create index if not exists applications_ip_idx on public.applications(ip_hash,created_at desc);
alter table public.applications enable row level security;
-- No public policies: only server-side service role can access applications.
